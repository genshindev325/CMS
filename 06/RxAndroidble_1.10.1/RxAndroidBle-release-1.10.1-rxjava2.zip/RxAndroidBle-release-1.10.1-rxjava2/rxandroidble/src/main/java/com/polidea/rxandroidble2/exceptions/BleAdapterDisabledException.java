package com.polidea.rxandroidble2.exceptions;

public class BleAdapterDisabledException extends BleException {
    // Disconnection related to disabled Bluetooth adapter
}
