package com.polidea.rxandroidble2.internal.connection;


interface MtuProvider {

    int getMtu();
}
