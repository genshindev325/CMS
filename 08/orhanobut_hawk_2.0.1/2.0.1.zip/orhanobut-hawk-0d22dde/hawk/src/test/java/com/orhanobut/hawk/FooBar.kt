package com.orhanobut.hawk

class FooBar {
  val name = "hawk"

  class InnerFoo {
    val name = "hawk"
  }
}
